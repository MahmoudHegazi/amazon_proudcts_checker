# __toString

```php
__toString ( ) : string
```

Returns the outer text of the current node.