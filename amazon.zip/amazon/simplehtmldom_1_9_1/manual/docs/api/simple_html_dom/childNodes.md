# childNodes

```php
childNodes ( [ int $idx = -1 ] ) : mixed
```

Returns children of the root element.

| Parameter | Description
| --------- | -----------
| `idx`     | Index of the child element to return.