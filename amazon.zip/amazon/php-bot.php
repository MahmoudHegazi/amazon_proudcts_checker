<?php
require 'simplehtmldom_1_9_1/simple_html_dom.php';
$amazon_domain = 'https://www.amazon.com/s?k=';
$ref_parameter = '&ref=nb_sb_noss';

$query = $_GET['q'];
if (!empty($query)) {
  $server_response = 200;
  $search_query = preg_replace('/\s+/', '+', $query);
  $final_url = $amazon_domain . $search_query . $ref_parameter;
  $html = file_get_html($final_url);
  $items = $html->find('h1.a-size-base',0)->children(0)->children(0)->children(0)->children(0)->children(0)->plaintext;
  $pieces = explode("of", $items);
  $showing_number = str_replace(' ', '', $pieces[0]);
  $total_result = str_replace(' ', '', explode("results", $pieces[1])[0]);

  //$the_test = $html->find('div[id=skiplink]');
  echo 'numbers: ' . $showing_number . '</br>';
  echo 'Result found: ' . $total_result;

  // for loop to get all title in that div store it then search and gg
  $products = $html->find('div.s-main-slot',0);
  //echo $products;
  echo $products;
} else {
  $result = 404;
  echo json_encode($result);
}



//$search_query = 'vitamin+c+serum+for+face+with+hyaluronic+acid';






//s-main-slot s-result-list s-search-results sg-row
//$items = $html->find('div.youclassname',0)->children(1)->outertext;
//skiplink
//$title = $html->find('title', 1);
//$image = $html->find('img', 1);

//  لما تعوز تعرف الاسم موجود ولا الموقع بيظيط استخدم in string
//  شوف هل الاسم اللي عملنا بيه سيرش نفس الاسم الموجود في او عنوان لو اه رجع true
//echo $title->plaintext."<br>\n";
//echo $image->src;
//echo $title->plaintext;
