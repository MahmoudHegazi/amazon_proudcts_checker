<?php
require 'simplehtmldom_1_9_1/simple_html_dom.php';
/* Do some operation here, like talk to the database, the file-session
 * The world beyond, limbo, the city of shimmers, and Canada.
 *
 * AJAX generally uses strings, but you can output JSON, HTML and XML as well.
 * It all depends on the Content-type header that you send with your AJAX
 * request. */



 $query = $_GET['q'];
 if (!empty($query)) {
   $server_response = 200;
   $google_url = 'https://www.google.com/search?q=';
   $search_for = $google_url . $query;
   $html = file_get_html('https://www.google.com/search?q=' . $query);
   $title = $html->find('title', 0);
   echo json_encode(htmlspecialchars($title->plaintext));
 } else {
   $result = 404;
   echo json_encode($result);
 }

 // In the end, you need to echo the result.
                      // All data should be json_encode()d.

                      // You can json_encode() any value in PHP, arrays, strings,
                      //even objects.

  /*
                      require 'simplehtmldom_1_9_1/simple_html_dom.php';

                      $html = file_get_html('http://www.google.com/');
                      $title = $html->find('title', 0);
                      $image = $html->find('img', 0);

                      echo '<img src="http://www.google.com/' . $image->src . '" alt="' . $title->plaintext . '">';


*/
?>
