
<!DOCTYPE html>
<html>
<head>

</head>
<body>
<input type="text" id="mysearch">
<button id="search_btn">Search</button>
<img src='' id='demo'>
<div id="myamazon"></div>
<!-- snip -->
<script>
const value_search = document.getElementById('mysearch');
const btn_search = document.getElementById('search_btn');
const img = document.getElementById('demo');
const result = document.getElementById('myamazon');

const amazon = {
   ajax_get : (query) => {
     function reqListener () {
       console.log(this.responseText);
     }

     var oReq = new XMLHttpRequest(); // New request object
     oReq.onload = function() {
         //alert(this.responseText);
         result.innerHTML=this.responseText;
     };
     oReq.open("get", "php-bot.php?q=" + query, true);
     oReq.send();
   },
   checker : () => {
     if (value_search.value != '') {
       amazon.ajax_get(value_search.value);
     } else {
       alert('You Have to enter search query');
     }
   }

}

btn_search.addEventListener('click', amazon.checker);



</script>
<!-- snip -->

</body>
</html>
